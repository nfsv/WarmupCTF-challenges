const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const express = require('express');
const fs = require('node:fs');
const jwt = require('jsonwebtoken');
const path = require('path');
const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

app.use(cookieParser());
app.use(express.urlencoded({ extended: true }));

function readFile(filePath) {
  try {
    return fs.readFileSync(filePath, { encoding: 'utf8' });
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

const FLAG = readFile('../flag');
const privKey = readFile('../priv.pem');
const verificationKey = readFile('../pub.crt');

const accounts = {
  admin: {
    password: FLAG,
    prevent: true
  },
  guest: {
    password: 'guest',
    prevent: true
  }
};

function verifyToken(token) {
  try {
    return jwt.verify(token, verificationKey, {
      algorithms: ['RS256', 'ES256', 'HS256']
    });
  } catch (error) {
    return false;
  }
}

function signToken(username) {
  try {
    return jwt.sign({ username: username }, privKey, {
      expiresIn: '1h',
      algorithm: 'RS256'
    });
  } catch (error) {
    return false;
  }
}

function isAllowed(token) {
  const user = verifyToken(token);

  if (user.username in accounts && !accounts[user.username].prevent) {
    return true;
  }
  return false;
}

function requireAuthentication(req, res, next) {
  if (typeof req.cookies.token !== 'string') {
    res.redirect('/login');
    return;
  }
  const user = verifyToken(req.cookies.token);
  if (!user) {
    res.clearCookie('token').redirect('/login');
    return;
  }
  res.locals.user = user;
  next();
}

function requireNoAuthentication(req, res, next) {
  if (typeof req.cookies.token === 'string') {
    res.status(403);
    res.send('you are already logged in.');
    return;
  }

  next();
}

app.get('/login', requireNoAuthentication, (req, res) => {
  res.render('login');
});

app.post('/login', requireNoAuthentication, (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  if (!username || !password) {
    res.status(400);
    res.send('username or password is empty.');
    return;
  }
  if (password !== accounts[username]['password']) {
    res.status(401);
    res.send('username or password is wrong.');
    return;
  }

  res.cookie('token', signToken(username), { httpOnly: true });
  res.redirect('/');
});

app.post('/logout', (req, res) => {
  res.clearCookie('token').redirect('login');
});

app.get('/flag', (req, res) => {
  if (isAllowed(req.cookies.token) !== true) {
    res.status(404);
    res.send('page not found.');
    return;
  }
  res.send(FLAG);
});

app.get('/', requireAuthentication, (req, res) => {
  res.render('index', { isAllow: isAllowed(req.cookies.token) });
});

app.listen(7000, '0.0.0.0');
