#!/usr/bin/env sh

echo $GZCTF_FLAG > /app/flag.txt
export GZCTF_FLAG=sus
./socat tcp-l:5000,reuseaddr,fork EXEC:"./chall"
