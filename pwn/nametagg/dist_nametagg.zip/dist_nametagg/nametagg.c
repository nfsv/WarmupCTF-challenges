#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

char *name_ptr;
int size;

void throw_name_tag() {
  if (!name_ptr) {
    puts("You haven't get a name tag yet!");
    return;
  }
  puts("You don't want it? Okay.");
  free(name_ptr);
  puts("Done throwing.");
}

void set_name() {
  printf("What's your name? > ");
  fgets(name_ptr, size, stdin);
  name_ptr[strcspn(name_ptr, "\n")] = '\0';
  puts("Gotcha.");
}

void new_name_tag() {
  while (1) {
    printf("How long is your name? > ");
    int count = scanf("%d%*c", &size);
    if (count < 1) {
      puts("Invalid input!");
      exit(1);
    }
    if (size <= 0) puts("Invalid size");
    else break;
  }
  size++; // null char
  name_ptr = (char*)malloc(size);
  set_name();
}

void fix_name_tag() {
  if (!name_ptr) {
    puts("You haven't get a name tag yet!");
    return;
  }
  puts("Seems to be a little bit mistake.\nLet's do it again!");
  set_name();
}

void show_name_tag() {
  if (!name_ptr) {
    puts("You haven't get a name tag yet!");
    return;
  }
  unsigned int len = strlen(name_ptr);
  char pad = '#';
  for (int i = 0; i < len+4; i++)
    printf("%c", pad);
  puts("");
  printf("%c %s %c\n", pad, name_ptr, pad);
  for (int i = 0; i < len+4; i++)
    printf("%c", pad);
  puts("");
}

void print_menu() {
  puts("1. Get a new name tag.");
  puts("2. Change name on the name tag.");
  puts("3. Throw away the name tag.");
  puts("4. Show the name tag.");
  puts("5. Exit.");
}

void exitt() {
  exit(1);
}

__attribute__((constructor)) void init() {
  alarm(30);
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
}

int main() {
  void (*funcs[])() = {new_name_tag, fix_name_tag, throw_name_tag, show_name_tag, exitt};
  int n_choice = sizeof(funcs)/sizeof(funcs[0]);
  puts("Hey, welcome to warmupCTF!\nWe haven't given you a name tag yet. So... we might not know your name.");
  puts("You should get one.");
  while (1) {
    puts("");
    print_menu();
    int choice;
    printf("Your choice > ");
    int count = scanf("%d%*c", &choice);
    if (count < 1 || choice < 1 || choice >= n_choice+1) {
      puts("Invalid input/choice.");
      exit(1);
    }
    funcs[choice-1]();
  }
  return 0;
}
