/* CIRCULAR ARRAY APPROACH FOR QUEUE */
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>
#include <time.h>
#include <unistd.h>

#define MAX_LEN 20

typedef void (*Song)(int num);
char input[30];
Song PLAYLIST[MAX_LEN];

struct Queue {
  Song *data;
  int write_to_index;
  int maxSize;
  int occupied;
};

typedef struct Queue Queue;

Queue initQueue(int size) {
  Queue q;
  q.write_to_index = -1;
  q.maxSize = size;
  q.occupied = 0;
  q.data = PLAYLIST;
  return q;
}

bool isEmpty(Queue q) {
  return q.occupied == 0;
}

bool isFull(Queue q) {
  return q.occupied == q.maxSize;
}

bool push(Queue *q, Song data) {
  if (isFull(*q)) return false;
  q->occupied++;
  q->write_to_index = (q->write_to_index + 1) % q->maxSize;
  q->data[q->write_to_index] = data;
  return true;
}

bool pop(Queue *q, Song* result) {
  if (isEmpty(*q)) return false;
  q->occupied--;
  int index = (q->write_to_index - q->occupied);
  if (index < 0) index += q->maxSize;
  *result = q->data[index];
  q->data[index] = NULL;
  return true;
}

bool peek(Queue q, Song *result) {
  if (isEmpty(q)) return false;
  int read_from_index = (q.write_to_index - q.occupied + 1);
  if (read_from_index < 0) read_from_index += q.maxSize;
  *result = q.data[read_from_index];
  return true;
}

bool peek_position(Queue q, int position, Song *result) {
  printf("Peek idx\n");
  if (isEmpty(q)) return false;
  int read_from_index = ((q.write_to_index - q.occupied + 1) + q.maxSize + abs(position)) % q.maxSize;
  printf("Indexing at %d\n", read_from_index);
  *result = q.data[read_from_index];
  return true;
}

void printArray(int* data, int n) {
  for (int i = 0; i < n; i++) {
    printf("%d ", data[i]);
  }
  printf("\n");
}

void melodyOfStars(int num) {
    if (num % 2 == 0) {
        system("echo 'Dreams take flight in the morning.'");
    } else {
        system("echo 'Dreams take flight in the night.'");
    }
    puts("");
}

void echoOfTime(int num) {
    printf("Whispers of the past unfold,\n");
    printf("Tales of love and hearts so bold,\n");
    printf("Echoes in the night retold %d times.\n", num);
    puts("");
}

void sunriseSerenade(int num) {
    if (num < 5) {
        printf("Sunrise brings a brand new day,\n");
        printf("Melodies of hope to stay,\n");
        printf("In the light, we'll find our way.\n");
    } else {
        printf("Sunrise heralds a day anew,\n");
        printf("Songs of hope for me and you,\n");
        printf("In the light, our path is true.\n");
    }
    puts("");
}

void twilightHarmony(int num) {
    printf("In the twilight's gentle glow,\n");
    printf("Harmony begins to grow,\n");
    printf("Hearts align and spirits flow %d times.\n", num);
    puts("");
}

void oceanWhispers(int num) {
    if (num % 2 == 0) {
        printf("Waves crash on the shore,\n");
        printf("Secrets whispered evermore,\n");
        printf("Nature's song we can't ignore.\n");
    } else {
        printf("Waves whisper on the shore,\n");
        printf("Secrets told forevermore,\n");
        printf("Nature's call we can't ignore.\n");
    }
    puts("");
}

void celestialDreams(int num) {
    printf("Stars above, they guide our dreams,\n");
    printf("Through the night with silver beams,\n");
    printf("Life is more than what it seems %d times.\n", num);
    puts("");
}

void moonlitSonata(int num) {
    if (num < 5) {
        printf("Beneath the moon's soft glow,\n");
        printf("A sonata starts to flow,\n");
        printf("In the night, our love will grow.\n");
    } else {
        printf("Under the moon's serene glow,\n");
        printf("A sonata begins to flow,\n");
        printf("In the night, our love will grow.\n");
    }
    puts("");
}

void forestRhapsody(int num) {
    printf("Leaves rustle in the breeze,\n");
    printf("Nature's symphony with ease,\n");
    printf("In the forest, hearts find peace %d times.\n", num);
    puts("");
}

void mountainEchoes(int num) {
    if (num % 2 == 0) {
        printf("From the peaks, a call resounds,\n");
        printf("Through the valleys, love abounds,\n");
        printf("In the echoes, life is found.\n");
    } else {
        printf("From the heights, a call resounds,\n");
        printf("Through the valleys, love abounds,\n");
        printf("In the echoes, life is found.\n");
    }
    puts("");
}

void radiantAurora(int num) {
    printf("Aurora paints the sky with light,\n");
    printf("Colors dancing through the night,\n");
    printf("In this wonder, pure delight %d times.\n", num);
    puts("");
}

int mySum(char buf[], int n) {
  int res = 0;
  for (int i = 0; i < n; i++) {
    res += buf[i];
  }
  return res * res + 69 * res - 8910;
}

__attribute__((constructor)) void init() {
  setbuf(stdin, NULL);
  setbuf(stdout, NULL);
}

int main() {
  printf("Hey what's your name? > ");
  fgets(input, 30, stdin);
  Song available[] = {melodyOfStars, echoOfTime, sunriseSerenade, twilightHarmony, oceanWhispers, celestialDreams, moonlitSonata, forestRhapsody, mountainEchoes, radiantAurora};
  int available_count = sizeof(available)/sizeof(available[0]);

  puts("\n\nIn CSC10002, Mr. Nguyen Minh Huy told us about a weird way to implement a queue, using a fixed-size array.");
  puts("I thought it was interesting and started coding. And only after I finished, I found out it's called circular queue.");
  puts("https://en.wikipedia.org/wiki/Circular_buffer");
  puts("The wiki page uses two variable: a write_to index and a read_from index.");
  puts("I decided to use a write_to index and the number of elements available to read");
  puts("Oh I also added peek_idx for more convinience.\n");

  puts("My friend Iwonart was impressed and wanted to use it for his music player.");
  puts("But I don't enjoy his playlist, so... you listen with him.");

  puts("You can choose how many songs to listen. And Iwon choose songs.");
  puts("Hope you have a good time.");
  puts("(hey if you find a good song that you want to listen first, just go, but if Iwon find out, you're screwed)");

  printf("Enter number of songs (less than %d): ", MAX_LEN);
  int size;
  scanf("%d", &size);
  if (size <= 0 || size > MAX_LEN) {
    printf("Hey...");
    exit(1);
  }

  Queue q = initQueue(size);

  puts("Now Iwon choose songs");
  for (int i = 0; i < size; i++) {
    push(&q, available[rand() % available_count]);
  }
  while (1) {
    puts("\n\nYour turn.");
    puts("1. Play next song");
    puts("2. Sneak another song");
    puts("3. Ask Iwon to add a song.");
    puts("4. Quit");
    printf("Now your choice: ");
    int choice;
    scanf("%d", &choice);
    Song current;
    if (choice == 1) {
      if (pop(&q, &current)) {
        current(mySum(input, 30));
      } else {
        puts("No more song to play.");
        break;
      }
    } else if (choice == 2) {
      int idx;
      printf("Enter index: ");
      scanf("%d", &idx);
      if (peek_position(q, idx, &current))
        current(mySum(input, 30));
      else puts("Some error?");
      if (rand() % 2) {
        puts("Hey what are you doing?");
        exit(1);
      }
    } else if (choice == 3) {
      if (push(&q, available[rand() % available_count])) {
        puts("OK, added.");
      } else {
        puts("Nah, the queue is full");
      }
    } else {
      exit(1);
    }
  }
  puts("");
  return 0;
}
