from binascii import crc32
from Crypto.Util.number import getPrime, bytes_to_long, long_to_bytes, GCD
import random

def genKeys():
    p = getPrime(512)
    q = getPrime(512)
    n = p*q
    phi = (p-1)*(q-1)
    return n, phi

n, phi = genKeys()
while True:
    e = random.randint(2, 2**32)
    if GCD(e, phi) == 1:
        break

d = pow(e, -1, phi)
flag = b"warmup{test_flag}"

checksum = crc32(long_to_bytes(e))
ct = pow(bytes_to_long(flag), d, n) # I will keep my private key!!

print(f"{n = }")
print(f"{ct = }")
print(f"{checksum = }")