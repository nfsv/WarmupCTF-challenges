from Crypto.Util.number import *
import random

FLAG = b'warmup{??????????????????????????????????????????????}'


def gen_key():
    p, q = [getPrime(1024) for _ in range(2)]
    return p, q


def pad(m, n):
    a, b, c = [random.randint(2, 2 ** 1023) for _ in range(3)]
    return a, b, c, (a ** 2 * m + b * m + c) % n


list_a, list_b, list_c, list_n, list_ct = [], [], [], [], []

for _ in range(6):
    p, q = gen_key()
    n = p * q
    a, b, c, m = pad(bytes_to_long(FLAG), n)
    ct = pow(m, 17, n)
    list_a.append(a)
    list_b.append(b)
    list_c.append(c)
    list_n.append(n)
    list_ct.append(ct)


print(f"{list_a = }")
print(f"{list_b = }")
print(f"{list_c = }")
print(f"{list_n = }")
print(f"{list_ct = }")
